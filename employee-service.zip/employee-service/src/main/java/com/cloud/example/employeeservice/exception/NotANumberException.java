package com.cloud.example.employeeservice.exception;

public class NotANumberException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String number;

	public NotANumberException() {
		
	}
	
	public NotANumberException(String number) {
		super();
		this.number = number;
	}
}
