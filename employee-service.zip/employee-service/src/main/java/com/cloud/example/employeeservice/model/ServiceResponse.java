package com.cloud.example.employeeservice.model;

import org.springframework.http.HttpStatus;

public class ServiceResponse {

	private HttpStatus status;
	private int statuscode;
	private String number;
	private String word;
	
	public ServiceResponse() {
		
	}
	
	public ServiceResponse(HttpStatus status, int statuscode, String number, String word) {
		super();
		this.status = status;
		this.statuscode = statuscode;
		this.number = number;
		this.word = word;
	}
	
	
	public HttpStatus getStatus() {
		return status;
	}
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	
	
	
}
