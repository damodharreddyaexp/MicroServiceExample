package com.cloud.example.employeeservice.inter;

public interface NumbersToWordsInterface {

	String convertNumberToWord(Long number);
}
