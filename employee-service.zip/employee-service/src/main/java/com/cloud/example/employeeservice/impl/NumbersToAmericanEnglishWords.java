package com.cloud.example.employeeservice.impl;

import com.cloud.example.employeeservice.inter.NumbersToWordsAbstractClass;
import com.cloud.example.employeeservice.inter.NumbersToWordsInterface;

public class NumbersToAmericanEnglishWords extends NumbersToWordsAbstractClass implements NumbersToWordsInterface {

	@Override
	public String convertNumberToWord(Long number) {
		// TODO Auto-generated method stub
		return null;
	}

}
