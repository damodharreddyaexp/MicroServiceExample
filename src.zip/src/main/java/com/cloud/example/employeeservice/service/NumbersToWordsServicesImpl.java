package com.cloud.example.employeeservice.service;

import org.springframework.stereotype.Service;

import com.cloud.example.employeeservice.factory.NumbersToWordsFactory;

@Service
public class NumbersToWordsServicesImpl {

	public String convertNumberToWord(Long number, String wordType) {
		// TODO Auto-generated method stub
		String numberInWords = NumbersToWordsFactory.getInstance(wordType).convertNumberToWord(number);
		return numberInWords;
	}
	
}
