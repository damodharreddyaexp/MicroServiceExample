package com.cloud.example.employeeservice.impl;

import java.text.DecimalFormat;

import com.cloud.example.employeeservice.inter.NumbersToWordsAbstractClass;
import com.cloud.example.employeeservice.inter.NumbersToWordsInterface;

public class NumbersToBritishEnglishWords extends NumbersToWordsAbstractClass implements NumbersToWordsInterface{

	@Override
	public String convertNumberToWord(Long number) {
		// 0 to 999 999 999
		if (number == 0) { return "zero"; }

		String snumber = Long.toString(number);

		// pad with "0"
		String mask = "000000000";
		DecimalFormat df = new DecimalFormat(mask);
		snumber = df.format(number);

		// XXXnnnnnn
		int millions  = Integer.parseInt(snumber.substring(0,3));
		// nnnXXXnnn
		int hundredThousands = Integer.parseInt(snumber.substring(3,6));
		// nnnnnnXXX
		int thousands = Integer.parseInt(snumber.substring(6,9));

		String tradMillions;
		switch (millions) {
		case 0:
			tradMillions = "";
			break;
		case 1 :
			tradMillions = convertLessThanOneThousand(millions)
			+ " million ";
			break;
		default :
			tradMillions = convertLessThanOneThousand(millions)
			+ " million ";
		}
		String result =  tradMillions;

		String tradHundredThousands;
		switch (hundredThousands) {
		case 0:
			tradHundredThousands = "";
			break;
		case 1 :
			tradHundredThousands = "one thousand ";
			break;
		default :
			tradHundredThousands = convertLessThanOneThousand(hundredThousands)
			+ " thousand ";
		}
		result =  result + tradHundredThousands;

		String tradThousand;
		tradThousand = convertLessThanOneThousand(thousands);
		result =  result + tradThousand;

		// remove extra spaces!
		return result.replaceAll("^\\s+", "").replaceAll("\\b\\s{2,}\\b", " ");
	}
	
}
