package com.cloud.example.employeeservice.factory;

import org.springframework.stereotype.Component;

import com.cloud.example.employeeservice.impl.NumbersToAmericanEnglishWords;
import com.cloud.example.employeeservice.impl.NumbersToBritishEnglishWords;
import com.cloud.example.employeeservice.inter.NumbersToWordsInterface;

@Component
public class NumbersToWordsFactory {

	private static NumbersToWordsInterface single_instance;	

	public static NumbersToWordsInterface getInstance(String wordType) {
		
		 if (wordType == "BRITISH_ENGLISH") { 
			 single_instance = new NumbersToBritishEnglishWords(); 
		 }
		 else if(wordType == "AMERICAN_ENGLISH"){
			 single_instance = new NumbersToAmericanEnglishWords();
		 }
	     return single_instance; 
	}
	
}
