package com.cloud.example.employeeservice;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableMap;
public class StringTokenizerWithMapTest {
	public static void main(String[] args) {
		
		 Map<String, String> map = ImmutableMap.copyOf(Splitter.on(',')
		.withKeyValueSeparator(";")
		  .split(checkNotNull("key1;value1,key2;value2,key3;,key4;value4,key5;value5"))
		 ); System.out.println(map); map.forEach((id, name) -> {
		  System.out.println("Key : " + id + " value : " + name); });
	}
	private static CharSequence checkNotNull(String input) {
		if ("".equals(input)) {
			throw new RuntimeException("Unexpeced format");
		}
		return input;
	}
	private static void SplitString() {
		StringTokenizer st = new StringTokenizer("key1;value1,key2;value2,key3;value3,key4;value4,key5;value5", ",");
	//	StringTokenizer st = new StringTokenizer("key1=value1&key2=value2&key3=value3&key4=value4&key5=value5", ",");
		Map<String, String> map = new HashMap<String, String>();

		while (st.hasMoreElements()) {

			String actualElement = st.nextToken();
			StringTokenizer et = new StringTokenizer(actualElement, ":");
			//StringTokenizer et = new StringTokenizer(actualElement, ",");
			System.out.println("et.countTokens()---->" + et.countTokens()); 
			/*
			 * if (et.countTokens() != 2) { throw new RuntimeException("Unexpeced format");
			 * }
			 */

			String key = et.nextToken();
			String value = et.nextToken();

			map.put(key, value);
		}

		System.out.println(map);
	}

}
